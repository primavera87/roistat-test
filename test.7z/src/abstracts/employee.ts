export interface Employee {
  id: number;
  name: string,
  phone: string,
  _showDetails: boolean,
  staff: object
}

export interface EmployeesForTable {
  head: [],
  body: []
}
