declare module "safe-localstorage";
